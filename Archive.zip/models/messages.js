const mongoose = require("mongoose");

const messageSchema = mongoose.Schema({
  _id: mongoose.Schema.Types.ObjectId,
  room_id: {
      type: String,
      required: true
  },
  timestamp: {
      type: Date,
      required: true
  },
  message_type: {
      type: Number,
      required: true
  },
  text: {
      type: String,
      required: true
  },
  media: {
      type: String,
      required: true
  },
  sent_by: {
      type: Number,
      required: true
  },
  received_by: {
      type: [],
      required: true
  },
//   name: {
//     type: String,
//     required: true
//   },
//   email: {
//     type: String,
//     required: true,
//     unique: true,
//     match: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
//   },
//   password: {
//     type: String,
//     required: true
//   }
});

module.exports = mongoose.model("Message", messageSchema);
